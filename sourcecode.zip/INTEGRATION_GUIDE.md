# Nexora dashboard — demo UI → Node.js + MySQL integration

## What changed

- `components/dashboard/AnalyticsSections.jsx` **replaces** the previous four analytics panels with the reference-style **Pipeline Pulse + Deals in Motion** and **Deal Velocity**. Both cards remain responsive and theme-aware.
- `components/dashboard/ReferenceOverview.jsx` **removes Top Country and duplicate DealsSpotlight**, keeps Sales Lifecycle/Overview and Schedule, and adds a functioning Add Task form (title, time, type, company, detail), completion toggle, pending filter and reset.
- `data/dashboard-velocity-demo.js` is the **new demo analytics adapter**; it is the single place to replace the synthetic stage split and quota target.
- `data/dashboard-reference-demo.js` continues to provide schedule and spotlight fixture records; the `getSalesSeries` Array.from error is fixed.
- `app/(dashboard)/dashboard/page.js` passes `{ start, end }` to AnalyticsSections. Keep existing KPI/date picker and other dashboard sections.

## Important metric semantics

**All displayed data are demonstration data**, including the `34 days` average cycle, the target quota and stage proportions. The chart's headline percentage is currently a **deal-to-lead proxy** rather than true stage-velocity. In production, decide whether the headline should be stage conversion, win rate, or on-time stage transition, then implement an exact backend definition. Do not relabel a proxy as a real measured KPI. The weekly/monthly/yearly bar series currently groups daily sample aggregates, NOT individual deal-stage transitions. The Pulse drop-down uses a 7/30/90-day lookback ending on the global dashboard end date; the Velocity switch selects a week, calendar year months, or rolling 5 years ending with that selected date.

## Recommended production stack

- Node.js: Express (or Fastify), `mysql2/promise`, Zod request validation, authentication middleware, and connection pooling.
- MySQL 8, administered through phpMyAdmin. phpMyAdmin is a management interface; your frontend **must not** connect to phpMyAdmin or directly to MySQL.
- Keep DB credentials and access tokens on the server. Use parameterized SQL, `organization_id` scoping, UTC timestamps and organization-local time zone when computing today's schedule.
- Implement transactions for state changes involving multiple records.

## Example SQL schema (starting point — migrate carefully)

```sql
CREATE TABLE crm_deals (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  organization_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(140) NOT NULL,
  company_name VARCHAR(160) NOT NULL,
  amount DECIMAL(15,2) NOT NULL DEFAULT 0,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  stage ENUM('qualified','proposal','negotiation','review','won','lost','stalled') NOT NULL DEFAULT 'qualified',
  opened_at DATETIME NOT NULL,
  won_at DATETIME NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_deals_org_stage (organization_id,stage),
  INDEX idx_deals_org_opened (organization_id,opened_at)
);

CREATE TABLE crm_deal_stage_history (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  organization_id BIGINT UNSIGNED NOT NULL,
  deal_id BIGINT UNSIGNED NOT NULL,
  from_stage VARCHAR(30) NULL,
  to_stage VARCHAR(30) NOT NULL,
  changed_at DATETIME NOT NULL,
  INDEX idx_history_org_date (organization_id,changed_at),
  INDEX idx_history_deal (deal_id,changed_at),
  FOREIGN KEY (deal_id) REFERENCES crm_deals(id)
);

CREATE TABLE crm_sales_targets (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  organization_id BIGINT UNSIGNED NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  revenue_target DECIMAL(15,2) NOT NULL,
  INDEX idx_targets_org_dates (organization_id,start_date,end_date)
);

CREATE TABLE crm_tasks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  organization_id BIGINT UNSIGNED NOT NULL,
  assigned_user_id BIGINT UNSIGNED NULL,
  title VARCHAR(140) NOT NULL,
  company_name VARCHAR(100) NOT NULL DEFAULT '',
  detail VARCHAR(240) NOT NULL DEFAULT '',
  task_type ENUM('task','call','meeting') NOT NULL DEFAULT 'task',
  due_at DATETIME NOT NULL,
  completed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_tasks_org_due (organization_id,due_at)
);
```

In a multi-tenant app, add foreign keys to `organizations` and `users` once their actual schema exists. Do not assume the example schema is ready to deploy unchanged.

## Example authenticated API contract

All endpoints require auth. Server derives `organization_id` from verified auth context, not a browser-supplied query parameter.

| Endpoint                                               | Response / behavior                                                                               |
| ------------------------------------------------------ | ------------------------------------------------------------------------------------------------- |
| `GET /api/dashboard/velocity?end=2026-10-15&mode=week` | `{ summary:{percent,change,openDeals}, bars:[{key,label,total,qualified,proposal,negotiation}] }` |
| `GET /api/dashboard/pulse?end=2026-10-15&period=month` | `{ pipeline,pipelineChange,conversion,revenue,quota,quotaPercent,avgCycleDays,cycleChange }`      |
| `GET /api/deals/spotlight?limit=3`                     | `{ items:[{id,name,company,amount,status}] }`                                                     |
| `GET /api/deals/export?scope=spotlight`                | Authenticated streamed CSV response, `Content-Disposition: attachment`                            |
| `GET /api/tasks?date=2026-10-15`                       | `{ items:[{id,date,time,title,company,detail,type,completed}] }`                                  |
| `POST /api/tasks`                                      | Body `{title,company,detail,type,dueAt}`; `201 {item}`                                            |
| `PATCH /api/tasks/:id`                                 | Body `{completed:true}`; `200 {item}`                                                             |
| `DELETE /api/tasks/:id`                                | `204`, only if you later expose a Delete action                                                   |

### Example Express route (illustrative)

```js
import express from "express";
import mysql from "mysql2/promise";
import { z } from "zod";
const router = express.Router();
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
});
// auth middleware must populate req.auth.organizationId, req.auth.userId.
router.post("/api/tasks", requireAuth, async (req, res) => {
  const schema = z.object({
    title: z.string().trim().min(1).max(140),
    company: z.string().max(100).default(""),
    detail: z.string().max(240).default(""),
    type: z.enum(["task", "call", "meeting"]),
    dueAt: z.string().datetime({ offset: true }),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success)
    return res.status(400).json({ error: "Invalid task data" });
  const t = parsed.data;
  const [result] = await pool.execute(
    "INSERT INTO crm_tasks (organization_id,assigned_user_id,title,company_name,detail,task_type,due_at) VALUES (?,?,?,?,?,?,?)",
    [
      req.auth.organizationId,
      req.auth.userId,
      t.title,
      t.company,
      t.detail,
      t.type,
      new Date(t.dueAt),
    ],
  );
  return res.status(201).json({ id: result.insertId });
});
```

`requireAuth` is an application-specific middleware placeholder: implement it before using the route. Wrap routes in a central error handler. For PATCH, constrain the UPDATE by **both id AND organization_id**; check `affectedRows` and return 404 if it is zero. Validate date range, timezone, type, user permissions and cross-tenant isolation on every endpoint.

## Replacing adapters — recommended order

1. Implement auth, MySQL pool and SQL migrations; seed an organization/user and some test deals/tasks.
2. Build backend endpoints and test via HTTP client or integration tests. Compute real velocity from `crm_deal_stage_history` grouped into the chosen buckets; compute actual cycle time from timestamps, and quota from targets for the matching period.
3. Create `lib/api/dashboard.js` as a fetch layer returning **exactly the shapes above**. Put JWT/session authentication in a secure cookie. Never embed DB credentials in client code.
4. Replace `useMemo(() => getVelocitySeries(...))` and `getPulseSnapshot(...)` with `useSWR` or TanStack Query keyed on end date and selector; display loading/empty/error states and keep last data while fetching.
5. In TodaySchedule, replace `scheduleItems` state initialization with fetched tasks; replace the local create/toggle state handlers with POST/PATCH requests; use optimistic updates plus rollback on failures.
6. For real calendar dates, derive today's date from the user's organization timezone; the current fixture date is **2026-10-15**, and task creation deliberately uses this demo date.
7. Verify role authorization, duplicate requests, database errors, currency and timezone correctness. Only then remove demo warnings.

## Demo behavior you can test now

- Week/Month/Year on Deal Velocity animate the stacked bar display.
- Pipeline Pulse period selector changes quota/pipeline snapshot values using sample daily aggregates.
- Export CSV downloads the three demo spotlight deals.
- Open Pipeline navigates to `/deals` (requires that your app has the route).
- Add Task reveals a form; Save Task adds to the sample schedule; pending filter, completion and reset work **in memory** until page reload (intentional).
- Top Country and its associated dashboard section have been removed; no other page routes were modified.
- Data source fixture values can be edited in `data/dashboard-demo.js`, `dashboard-reference-demo.js`, and `dashboard-velocity-demo.js`.

Backend guidance reminder
For later integration with MySQL (phpMyAdmin) + Node.js backend:
Deal Velocity
Replace:

- getVelocitySeries()
- getVelocitySummary()
  with API calls like:
- GET /api/dashboard/velocity?start=...&end=...&group=week|month|year
- GET /api/dashboard/velocity-summary?start=...&end=...
  Pipeline Pulse
  Replace:
- getPulseSnapshot()
- getSpotlightDeals()
  with:
- GET /api/dashboard/pulse?period=week|month|quarter
- GET /api/deals/spotlight
  Sales Overview
  Replace:
- getSalesSeries()
  with:
- GET /api/dashboard/sales?start=...&end=...&resolution=week|month|quarter
  The comments in the code already point to this.

# Nexora dashboard visual and interaction polish

Replace these exact files in your existing Next.js project:

- components/dashboard/AnalyticsSections.jsx
- components/dashboard/ReferenceOverview.jsx
- components/dashboard/ActivitySections.jsx
- components/dashboard/CompactSelect.jsx (new shared control)

DO NOT replace existing data modules, dashboard page, sidebar, or global theme.

## Changes

- Pipeline Pulse: fixed 112x112 SVG quota ring (no elliptical distortion); compact, keyboard-accessible period menu.
- Deal Velocity: demo-backed stage toggles remain functional; bars animate on period/stage changes and show stage totals in hover/focus tooltips.
- Sales Overview: large, wide column next to left stack; visible graph nodes, hover/focus/click revenue tooltip; compact themed grouping menu.
- Left column: Sales Lifecycle and Today's Schedule, retaining Add Task, checkbox, Pending and demo reset.
- Activity & insights: removed Recent Activity and Upcoming Follow-ups; retained responsive Pipeline Insights and Quick Actions with restrained hover effects.

## TODO(API) / Node.js + MySQL

- Keep existing adapter signatures from data/dashboard-velocity-demo.js and data/dashboard-reference-demo.js. UI components should not query MySQL directly.
- GET /api/dashboard/pulse?end=YYYY-MM-DD&period=week|month|quarter => {quotaPercent,pipeline,pipelineChange,conversion,avgCycleDays,cycleChange}.
- GET /api/dashboard/velocity?end=YYYY-MM-DD&group=week|month|year => [{key,label,total,qualified,proposal,negotiation}]. Return stage counts for each group; derive totals server-side from deal_stage_history with an organization/tenant filter.
- GET /api/dashboard/sales?start=YYYY-MM-DD&end=YYYY-MM-DD&resolution=week|month|quarter => [{label,revenue}]. Ensure values are authorized and aggregated server-side from WON deals/payments per your business definition.
- GET /api/dashboard/insights?start=&end= => aggregate values compatible with the current `insights` prop; the source in `data/dashboard-insights.js` can eventually be removed.
- Schedule uses existing local-state Add Task implementation. Hook it to GET /api/tasks, POST /api/tasks, PATCH /api/tasks/:id using the previous INTEGRATION_GUIDE.md. Client must handle loading/errors and invalidate/re-fetch after writes. Validate and enforce tenant + user permissions in Node.js.
- phpMyAdmin is only the GUI for administering MySQL; run backend SQL through mysql2 prepared statements and never expose database credentials to browser.

## Test checklist

- 320px/375px mobile, tablet, and desktop; dark/light theme.
- Pipeline menu opens above content and closes on Escape/outside; no clipping.
- Quota ring stays perfectly round; stage filters and period buttons change plotted demo values.
- Sales chart shows tooltips on point hover/focus/click, and changes aggregation with menu selection.
- Add Task, Pending, reset continue to work; Quick Actions navigate to existing routes.

Conventional commit: `fix(dashboard): polish charts, menus and responsive insight layout`

# Nexora layout refinements

Replace exactly these two files in your Next.js project:

- components/dashboard/ReferenceOverview.jsx
- components/dashboard/ActivitySections.jsx

## Layout

On xl screens the left column stacks Sales Lifecycle above Sales Overview; Today’s Schedule fills the same total row height on the right. Below xl, cards stack vertically.

## Pipeline Insights demo updates

The Pipeline Insights panel displays visible values that recalculate from the existing date-filtered `insights` prop and a 15-second **simulated** timer. It displays “Today / Last 24 hours · demo preview” as future API intent; the demo data is NOT a true time-filtered 24-hour dataset. Follow-up counts are independently simulated and do not modify Today’s Schedule tasks.

## Backend integration (Node.js + MySQL)

1. Add an authenticated `GET /api/dashboard/insights?window=24h` endpoint that returns `{capturedLeads24h,revenueConversion24h,completedFollowUps24h,pendingFollowUps,updatedAt}` scoped by organization/team and timezone.
2. Aggregate real leads/deals/tasks with parameterized `mysql2/promise` queries. Do not rely on browser timestamps to define "today".
3. Replace `useDemoLiveInsights()` with SWR/TanStack Query polling every 15 seconds or SSE. Map the API response into the three display entries; delete `demoTick` and simulated numbers.
4. Keep the existing `ReferenceOverview` data contracts. For the schedule, replace demo `scheduleItems` state with GET/POST/PATCH task endpoints; update using server-authoritative responses.
5. Test date selection, desktop equal-height alignment, tablet/mobile stacking, both themes, and Add Task / completion.

**Note:** Full Next.js browser verification was not possible in this environment. Code was syntax checked only.
